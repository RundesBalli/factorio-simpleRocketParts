data.raw["recipe"]["rocket-part"].ingredients = {{"rocket-control-unit", 1},{"rocket-fuel", 1}}
data.raw["recipe"]["rocket-control-unit"].ingredients = {{"iron-plate", 45},{"copper-plate", 45}}
data.raw["recipe"]["rocket-fuel"].ingredients = {{"coal", 90}}
data.raw["recipe"]["satellite"].ingredients = {{"iron-plate", 9000},{"copper-plate", 4500}}
