require("recipe")
require("prototype.item.rocket-thingy")
require("prototype.recipe.rocket-thingy")
