data:extend({
  {
    type = "item",
    name = "rocket-thingy",
    group = "intermediate-products",
    subgroup = "intermediate-product",
    order = "d[rocket-parts]-c[rocket-thingy]",
    icon = "__SimpleRocketParts__/graphics/icons/rocket-thingy.png",
    icon_size = 128,
    stack_size = 100
  }
})
